
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css'; 

function Login() {
  const [credentials, setCredentials] = useState({
    accountNumber: '',
    password: ''
  });
  const [message, setMessage] = useState('');
  const navigate = useNavigate(); 

  const handleChange = (e) => {
    setCredentials({ ...credentials, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(credentials);
    setMessage('Login successful!');
    
    
    navigate('/dashboard');
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <h2 className="login-title">Log In</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="accountNumber">Account Number</label>
            <input
              type="text"
              className="form-control"
              id="accountNumber"
              name="accountNumber"
              value={credentials.accountNumber}
              onChange={handleChange}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              className="form-control"
              id="password"
              name="password"
              value={credentials.password}
              onChange={handleChange}
              required
            />
          </div>
          <button 
            type="submit" 
            className="btn mt-3" 
            style={{ backgroundColor: '#065c70', color: '#fff' }}
          >
            Log In
          </button>
        </form>
        {message && <div className="login-message mt-3">{message}</div>}
      </div>
    </div>
  );
}

export default Login;
