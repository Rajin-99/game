// src/Transaction.js
import React, { useState } from 'react';
import './Transaction.css'; // Ensure you create and import this CSS file

const Transaction = () => {
  const [transactions, setTransactions] = useState([]);
  const [formData, setFormData] = useState({
    accountNumber: '',
    amount: '',
    type: 'Deposit' // Default to Deposit
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setTransactions([...transactions, { ...formData, date: new Date().toLocaleDateString() }]);
    setFormData({ accountNumber: '', amount: '', type: 'Deposit' }); // Reset form
  };

  const renderForm = () => {
    return (
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="accountNumber">Account Number</label>
          <input
            type="text"
            className="form-control"
            id="accountNumber"
            name="accountNumber"
            value={formData.accountNumber}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="amount">Amount</label>
          <input
            type="number"
            className="form-control"
            id="amount"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            required
            min="0" // Ensure only positive numbers are allowed
            step="any" // Allow any decimal places
          />
        </div>
        <button 
          type="submit" 
          className="btn-custom mt-3"
        >
          {formData.type}
        </button>
      </form>
    );
  };

  return (
    <div className="container py-5">
      <h2>Transaction Management</h2>

      {/* Transaction Type Selection */}
      <div className="mb-4">
        <h3>Select Transaction Type</h3>
        <div className="btn-group">
          <button
            className={`btn ${formData.type === 'Deposit' ? 'active' : ''}`}
            style={{ backgroundColor: formData.type === 'Deposit' ? '#065c70' : '#fff', color: formData.type === 'Deposit' ? '#fff' : '#065c70' }}
            onClick={() => setFormData({ ...formData, type: 'Deposit' })}
          >
            Deposit
          </button>
          <button
            className={`btn ${formData.type === 'Withdrawal' ? 'active' : ''}`}
            style={{ backgroundColor: formData.type === 'Withdrawal' ? '#065c70' : '#fff', color: formData.type === 'Withdrawal' ? '#fff' : '#065c70' }}
            onClick={() => setFormData({ ...formData, type: 'Withdrawal' })}
          >
            Withdraw
          </button>
        </div>
      </div>

      {/* Render Form Based on Transaction Type */}
      {renderForm()}

      {/* Transaction History */}
      <div className="mt-4">
        <h3>Transaction History</h3>
        <button 
          className="btn-custom mt-2" 
          onClick={() => alert('Show History')}
        >
          History
        </button>
        <table className="table table-striped transaction-table mt-3">
          <thead>
            <tr>
              <th>Date</th>
              <th>Account Number</th>
              <th>Type</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction, index) => (
              <tr key={index}>  
                <td>{transaction.date}</td>
                <td>{transaction.accountNumber}</td>
                <td>{transaction.type}</td>
                <td>${transaction.amount}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Transaction;
